<?php
if (isset($_SESSION['page'])) {
} else {
    header("location: ../index.php?page=dashboard&error=true");
}
if (isset($_POST['bulan'])) {
    $pencarian = $_POST['bulan'];
    $bulan = date('m', strtotime($pencarian));
    $tahun = date('Y', strtotime($pencarian));
    $hasil = jumlah_hari($bulan, $tahun);
    $tampil_date = date('F', strtotime($pencarian));
} else {
    $bulan = date('m');
    $tahun = date('Y');
    $hasil = jumlah_hari($bulan, $tahun);
    $tampil_date = date('F');
}

?>
<div class="content-header ml-3 mr-3">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">DATA PRESENSI BULANAN</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active">Data Presensi / Bulanan</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>


<section class="content ml-3 mr-3">
    <div class="content">
        <div class="container-fluid">

            <div class="row bg-secondary mt-2 pt-2 pb-3 mb-4">
                <div class="col-md-4 pt-3" style="height: -50px;">
                    <form method="POST">
                        <input required placeholder="yyyy-mm" type="text" class="form-control bulan" name="bulan" autocomplete="off">
                </div>
                <div class="col-md-4 pt-3">
                    <button type="submit" class="btn btn-info"><i class="fas fa-search mr-1"></i>Cari</button>
                    <button id="button-a" type="button" class="btn btn-success ml-2"><i class="far fa-file-excel mr-1"></i>Export</button>
                    <!--
                    <button type="button" class="btn btn-primary ml-2" onclick="printDiv()"><i class="fas fa-print mr-1"></i>Cetak</button>
                    -->
                    <button type="button" class="btn btn-primary ml-2" onclick="printContent('table-bulanan')"><i class="fas fa-print mr-1"></i>Cetak</button>
                    </form>
                </div>
                <div class="col-md-4 pt-3 pr-5" style="font-size:18px; text-align: right;">
                    <?php echo $tampil_date . " " . $tahun; ?>
                </div>
            </div>

            <div class="table-responsive mt-2" id="table-bulanan">
                <table class="table table-bordered dt-responsive nowrap" style="width: 100%;">
                    <thead class="text-center">
                        <tr>
                            <th rowspan="2" bgcolor="#F3F3F3" scope="col">Nama</th>
                            <th rowspan="2" bgcolor="#F3F3F3" scope="col">ID</th>
                            <th colspan="<?php echo $hasil; ?>" bgcolor="#F3F3F3" scope="col">Daftar Presensi Bulan  <?php echo $tampil_date . " " . $tahun;?> </th>
                            <th colspan="6" bgcolor="#F3F3F3" scope="col">Jumlah Kehadiran</th>
                        </tr>
                        <?php

                        for ($i = 1; $i <= $hasil; $i++) {

                            $index = $i;
                        ?>
                            <th scope="col" bgcolor="#F3F3F3"><?php echo $i; ?></th>
                        <?php

                        }
                        ?>
                        <th bgcolor="#F3F3F3" scope="col">A</th>
                        <th bgcolor="#F3F3F3" scope="col">B</th>
                        <th bgcolor="#F3F3F3" scope="col">T</th>
                        <th bgcolor="#F3F3F3" scope="col">S</th>
                        <th bgcolor="#F3F3F3" scope="col">I</th>
                        <th bgcolor="#F3F3F3" scope="col">H</th>
                    </thead>

                    <tbody>
                        <?php
                        $date = date('d');
                        $hari_libur = 0;
                        $alpa = $hasil;
                        $sql = mysqli_query($dbconnect, "SELECT * FROM tb_id");
                        while ($row = mysqli_fetch_array($sql)) {
                            $id = $row['id'];
                            $nama = $row['nama'];

                            echo "<tr>";
                            echo "<td bgcolor='#FAFAFA'>" . $nama . "</td>";
                            echo "<td bgcolor='#FAFAFA'>" . $id . "</td>";

                            for ($panjang = 1; $panjang <= $hasil; $panjang++) {

                                //if ($panjang <= $hasil) {
                                ///select array berdasarkan tanggal
                                $convert_date = $tahun . "-" . $bulan . "-" . $panjang;
                                $loop = mysqli_query($dbconnect, "SELECT id, status FROM tb_absen WHERE id='$id' AND date = '$convert_date'");
                                $data = mysqli_num_rows($loop);

                                $day = getday($convert_date);
                                //echo $panjang;
                                if ($data > 0) {
                                    while ($status = mysqli_fetch_assoc($loop)) {

                                        $id = $status['id'];
                                        if ($status['status'] == "A") {

                                            echo "<td class='text-center' bgcolor='#F0386A'>" . $status['status'] . "</td>";
                                        } else if ($status['status'] == "B") {
                                            $alpa = $alpa - 1;
                                            echo "<td class='text-center' bgcolor='#F9D612'>" . $status['status'] . "</td>";
                                        } else if ($status['status'] == "I") {
                                            $alpa = $alpa - 1;
                                            echo "<td class='text-center' bgcolor='#72ADF5'>" . $status['status'] . "</td>";
                                        } else if ($status['status'] == "S") {
                                            $alpa = $alpa - 1;
                                            echo "<td class='text-center' bgcolor='#62E3EB'>" . $status['status'] . "</td>";
                                        } else if ($status['status'] == "T") {
                                            $alpa = $alpa - 1;
                                            echo "<td class='text-center' bgcolor='#A7ACB1'>" . $status['status'] . "</td>";
                                        } else if ($status['status'] == "H") {
                                            $alpa = $alpa - 1;
                                            echo "<td class='text-center' bgcolor='#66EDC0'>" . $status['status'] . "</td>";
                                        }
                                    }
                                } else {
                                    if ($day == $libur1 || $day == $libur2) {
                                        $hari_libur += 1;

                                        echo "<td class='text-center' bgcolor='#DCFCFF'>L</td>";
                                    } else {
                                        echo "<td class='text-center' bgcolor='#F0386A'>A</td>";
                                    }
                                }
                            }


                            $date_awal = $tahun . "-" . $bulan . "-1";
                            $date_akhir = $tahun . "-" . $bulan . "-" . $hasil;
                            //echo $hari_libur;
                            $total_alpa = $alpa - $hari_libur;
                            echo "<td class='text-center'>" . $total_alpa . "</td>";
                            echo "<td class='text-center'>" . num_row('tb_absen', 'status', 'B', $id, $date_awal, $date_akhir) . "</td>";
                            echo "<td class='text-center'>" . num_row('tb_absen', 'status', 'T', $id, $date_awal, $date_akhir) . "</td>";
                            echo "<td class='text-center'>" . num_row('tb_absen', 'status', 'S', $id, $date_awal, $date_akhir) . "</td>";
                            echo "<td class='text-center'>" . num_row('tb_absen', 'status', 'I', $id, $date_awal, $date_akhir) . "</td>";
                            echo "<td class='text-center'>" . num_row('tb_absen', 'status', 'H', $id, $date_awal, $date_akhir) . "</td>";
                            $alpa = $hasil;
                            $hari_libur = 0;
                            echo "<tr>";
                        }

                        ?>

                    </tbody>
                </table>
            </div>


        </div>
    </div>
</section>

<script>
    function printContent(el) {
        var restorepage = document.body.innerHTML;
        var printcontent = document.getElementById(el).innerHTML;
        document.body.innerHTML = printcontent;
        window.print();
        document.body.innerHTML = restorepage;
    }
</script>