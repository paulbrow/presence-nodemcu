
<div class="content-header ml-3 mr-3">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">TAMBAH PEGAWAI</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="index.php?page=dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active">Tambah Pegawai</li>
                </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>

<section class="content ml-3 mr-3">
    <div class="content">
        <div class="container-fluid">

            <div clas="row">

                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            Form Registrasi

                            <a href="#" class="ml-auto" onclick="alertError()"><i class="fas fa-question-circle"></i></a>
                           

                        </div>
                        <div class="card-body">
                            <div class="form-group">

                                <form action="./konfig/prosesdaftar/daftar-pegawai.php" method="POST">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">ID Fingger</label>
                                        <input  required  id="demo" class="form-control" type="number" name="id" placeholder="Masukan ID Fingger">
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Nama</label>
                                        <input id="nama" readonly required class="form-control" name="nama" type="text" autocomplete="off" place="Masukan Nama">
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Chat ID Telegram</label>
                                        <input id="chat-id" readonly required class="form-control" name="chatID" type="text" autocomplete="off" place="Masukan chat id telegram">
                                    </div>

                                    <div class="form-group">

                                        <button id="btnSimpan" type="submit" class="btn btn-success mt-3 ml-3 float-right">Simpan</button>
                                    </div>
                                </form>
                                <button id="btnSinkron" class="btn btn-primary mt-3 ml-3 float-right" onclick="myFunction()">Sinkron</button>
                                <a href="./konfig/prosesdaftar/hapusentry.php" id="btnBatal" class="btn btn-danger mt-3 float-right">Batal</a>


                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-header">
                            Respon Kontroler
                        </div>
                        <div class="card-body">
                            <h5 class="card-title" id="message"> None </h5>
                            <p class="card-text mt-1"><?php echo "IP : " . $ip ?></p>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<script>
    alert("Jangan gunakan tombol enter pada keyboard untuk melakukan sinkron, gunakan tombol sinkron untuk terkoneksi dengan kontroler. ");
    
    var formID;
    var btnSimpan = document.getElementById("btnSimpan");
    var btnBatal = document.getElementById("btnBatal");
    var btnSinkron = document.getElementById("btnSinkron");
    
    
    btnSimpan.style.display = 'none';
    btnBatal.style.display = 'none';
    btnSinkron.style.display = 'block';
   
   function alertError(){
    var delete_data = confirm("Jika kontroler terus menerus masuk pada mode tambah pegawai/user, silahkan klik Ya/Oke untuk menghapus history permintaan kontroler masuk ke mode tambah data. Kemudian reset kontroler.");
    if(delete_data == true){
             $.ajax({
                type: "GET",
                url: "konfig/prosesdaftar/hapusentry.php",
                cache: false,
                //dataType: "JSON",
                success: function(response) {
                    alert("Reset/Restart Kontroler Sekarang.");
                }
            });
    }
   }

    function myFunction() {
        formID = document.getElementById("demo").value;
        if (formID == "") {
            alert("ID Finger Tidak Boleh Kosong");
        } else {
            $.ajax({
                type: "POST",
                url: "konfig/prosesdaftar/daftar.php",   
                data: {
                    id: formID,
                    parameter: 'cek'
                },
                cache: false,
                //dataType: "JSON",
                success: function(response) {
                    if (response == "1") {
                        var konfirm = confirm("ID Telah terdaftar, Pilih Ya/Oke untuk melakukan update Data");
                        if (konfirm == true) {
                            daftarPengguna(); //jika update bersedia
                        } else {
                            //nothing
                        }
                    } else {
                        $('#message').text(response);
                        tungguResponse();
                    }
                }
            });
        }

    }


    function daftarPengguna() {
        $.ajax({
            type: "POST",
            url: "konfig/prosesdaftar/daftar.php",
            data: {
                id: formID,
                parameter: 'daftar'
            },
            cache: false,
            success: function(response) {
                $('#message').text(response);
                tungguResponse();
            }
        });
    }

    function tungguResponse() {
        document.getElementById("demo").readOnly = true;
        $.ajax({
            type: "POST",
            url: "konfig/prosesdaftar/daftar.php",
            data: {
                id: 'response',
                parameter: 'response'
            },
            cache: false,
            success: function(response) {
                $('#message').text(response);

                if (response == 'Sukses') {
                    document.getElementById("nama").readOnly = false;
                    document.getElementById("chat-id").readOnly = false;
                    prosesSelesai();
                    return false;
                }
                console.log(response);
                setTimeout(tungguResponse, 4000);
            }
        });
    }

    function prosesSelesai() {
        console.log("haloo");
        if (btnSimpan.style.display === "none" && btnBatal.style.display === "none" && btnSinkron.style.display === "block") {
            btnSimpan.style.display = 'block';
            btnBatal.style.display = 'block';
            btnSinkron.style.display = 'none';
        }
    }
</script>