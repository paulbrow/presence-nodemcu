<?php 
session_start();
if(isset($_SESSION['page'])){

	if(isset($_POST['parameter'])){
		include 'connection.php';
		$parameter = mysqli_real_escape_string($dbconnect, $_POST['parameter']);
		$id = mysqli_real_escape_string($dbconnect, $_POST['id']);
		$nama = mysqli_real_escape_string($dbconnect, $_POST['nama']);
		$telegram = mysqli_real_escape_string($dbconnect, $_POST['telegram']);
		
		$sql = mysqli_query($dbconnect, "UPDATE tb_id SET id='$id', nama='$nama', telegram_id='$telegram' WHERE id='$parameter'");
			if($sql){
				$error = "false";
			}
			else{
				$error = "true";
			}
	}else{
		$error = "true";
	}

}else{
	$error = "true";
}
header("location:../index.php?page=pegawai&error=".$error);
?>