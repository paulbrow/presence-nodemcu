<?php
include '../connection.php';
$error = 'true';
if(isset($_POST['id']) && isset($_POST['nama'])){
    $id = mysqli_real_escape_string($dbconnect, $_POST['id']);
    $nama = mysqli_real_escape_string($dbconnect, $_POST['nama']);
    $chat_id = mysqli_real_escape_string($dbconnect, $_POST['chatID']);

    $sql = mysqli_query($dbconnect, "SELECT * FROM tb_id WHERE id='$id'");
    $cek = mysqli_num_rows($sql);
    if($cek > 0){
        mysqli_query($dbconnect, "UPDATE tb_id SET nama='$nama',telegram_id='$chat_id' WHERE id='$id'");
        $error = 'false';
    }else{
        mysqli_query($dbconnect, "INSERT INTO tb_id (id,nama,telegram_id) VALUES ('$id','$nama','$chat_id')");
        $error = 'false';
    }
   
    mysqli_query($dbconnect, "DELETE FROM tb_state");
    header("location:../../index.php?page=tambah-pegawai&error=".$error);
    exit();
}
?>