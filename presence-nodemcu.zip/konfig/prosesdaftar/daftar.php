<?php
include '../connection.php';
$id = $_POST['id'];
$parameter = $_POST['parameter'];

if ($parameter == "cek" && $id != "kontroler") {
    mysqli_query($dbconnect, "DELETE FROM tb_state");
    $sql = mysqli_query($dbconnect, "SELECT * FROM tb_id WHERE id = $id");
    $cek = mysqli_num_rows($sql);
    if ($cek > 0) {
        echo '1';
    } else {
        $sql = mysqli_query($dbconnect, "INSERT INTO tb_state VALUES ('1','','$id')");
        if ($sql) {
            echo 'Melakukan Proses';
        } else {
            echo 'Proses Gagal!';
        }
    }
} else if ($parameter == "daftar" && $id != "kontroler") {
    $sql = mysqli_query($dbconnect, "INSERT INTO tb_state VALUES ('1','','$id')");
    if ($sql) {
        echo 'Melakukan Proses';
    } else {
        echo 'Proses Gagal!';
    }
} else if($parameter == "response" && $id == "response"){
    $sql = mysqli_query($dbconnect, "SELECT * FROM tb_state");
    $response = mysqli_fetch_assoc($sql);
    if($response['pesan_kontroler'] != ""){
        echo $response['pesan_kontroler'];
    } else{
        echo "Melakukan Proses Pendaftaran";
    } 

} else if($id == "kontroler" && $parameter!=""){
    $sql = mysqli_query($dbconnect, "UPDATE tb_state SET status='0', pesan_kontroler='$parameter'");
    echo $parameter;
}

?>
