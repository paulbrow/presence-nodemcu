<?php
if(isset($_POST['id'])){
	include 'function.php';
	$uid = $_POST['id'];
	$hari_ini = date('Y-m-d');
	$day = getday($hari_ini); //cek hari ini untuk parameter pada kondisi hari libur
	
	if($day == $libur1 || $day == $libur2){ //kondisi hari libur
		echo "Hari Libur";
	}else{
		$cek_uid = uid($uid); //cek UID apakah ada di database
		if($cek_uid == "0"){ // jika ID ada
			$time = date('H:i:s');
			$cek_absen = cektime($time, $masuk_mulai, $masuk_akhir, $keluar_mulai, $keluar_akhir); //menjalankan algoritma absen membandingkan jam
			$simpan_absen = postdata($uid, $hari_ini, $time, $cek_absen); //menyimpan hasil jam dan status absen di database
			$message = telegram($uid, $time, $simpan_absen, $bot_token); // mengirimkan pesan ke telegram
			echo $simpan_absen;
			}else{ //jika ID tidak ada
			echo "ID Tidak Ada";
		}
	}

}else{
	echo "Coba Lagi";
}
?>